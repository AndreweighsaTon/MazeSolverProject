# MegaMaze Frontend

To view the web UI, double click on index.html (or open it in your favorite browser).